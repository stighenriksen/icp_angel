Chapter 4 programs

cube: displays a rotating cube with vertex colors interpolated across faces

cubev: same as cube but with element arrays