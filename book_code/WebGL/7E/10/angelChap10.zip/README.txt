Chapter 10 Programs:

particleSystem: particles in box with repulsion, gravity, restitution

particleDiffusion1: randomly moving  particles leaving colors at their positions which are diffused on successive frames.

particleDiffusion2: same particle system but particles look at their environment and depending on their color and color at new location move to x or y axis.

madelbrot: mandelbrot set generating program.