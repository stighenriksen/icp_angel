Chapter 11 Programs:

vertices.js: three versions of the data vertex data

patches.js: teapot patch data

teapot1: wire frame teapot by recursive subdivision of Bezier curves

teapot2: wire frame teapot using polynomial evalation

teapot3: same as teapot2 with rotation

teapot4: shaded teapot using polynomial evaluation and exact normals

teapot5: shaded teapot using polynomial evaluation and normals computed for each triangle


